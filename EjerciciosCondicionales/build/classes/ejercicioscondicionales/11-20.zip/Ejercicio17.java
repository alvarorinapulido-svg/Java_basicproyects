/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioscondicionales;

import java.util.Scanner;

/**
 *
 * @author alvaro.rinpul
 */
public class Ejercicio17 {
    
        public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
            System.out.println("Introduce un numero");
        int num1 = sc.nextInt();
        int ultimaCifra;
        ultimaCifra=num1%10;
        System.out.println("La ultima cifra del valor es: "+ultimaCifra);
    }          
}
