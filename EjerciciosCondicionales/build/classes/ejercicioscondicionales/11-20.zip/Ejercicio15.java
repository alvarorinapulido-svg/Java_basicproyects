/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioscondicionales;

import java.util.Scanner;

/**
 *
 * @author alvaro.rinpul
 */
public class Ejercicio15 {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce el caracter con el que haras la piramide");
        char simbolo = sc.next().charAt(0);
        System.out.println("Introduce la dirección");
        System.out.println("1.Arriba 2.Abajo 3.Derecha 4.Izquierda");
        int direccion = sc.nextInt();
        switch (direccion){
            case 1:
                System.out.println("   "+simbolo+"   ");
                System.out.println("  "+simbolo+simbolo+simbolo+"  ");
                System.out.println(" "+simbolo+simbolo+simbolo+simbolo+simbolo+" ");
                System.out.println(""+simbolo+simbolo+simbolo+simbolo+simbolo+simbolo+simbolo+"");
                break;
            case 2:
                System.out.println(""+simbolo+simbolo+simbolo+simbolo+simbolo+simbolo+simbolo+"");
                System.out.println(" "+simbolo+simbolo+simbolo+simbolo+simbolo+"");
                System.out.println("  "+simbolo+simbolo+simbolo+"  ");
                System.out.println("   "+simbolo+"   ");
                break;
            case 3:
                System.out.println(""+simbolo+"");
                System.out.println(""+simbolo+simbolo+"");
                System.out.println(""+simbolo+simbolo+simbolo+"");
                System.out.println(""+simbolo+simbolo+simbolo+simbolo+"");
                System.out.println(""+simbolo+simbolo+simbolo+"");
                System.out.println(""+simbolo+simbolo+"");
                System.out.println(""+simbolo+"");
                break;
            case 4:
                System.out.println("   "+simbolo+"");
                System.out.println("  "+simbolo+simbolo+"");
                System.out.println(" "+simbolo+simbolo+simbolo+"");
                System.out.println(""+simbolo+simbolo+simbolo+simbolo+"");
                System.out.println(" "+simbolo+simbolo+simbolo+"");
                System.out.println("  "+simbolo+simbolo+"");
                System.out.println("   "+simbolo+"");
                break;
            default:
                System.out.println("El numero no es correcto");
        }
    }
    
}
