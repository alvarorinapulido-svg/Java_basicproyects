/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioscondicionales;

import java.util.Scanner;

/**
 *
 * @author alvar
 */
public class Ejercicio11 {
    
     public static void main(String[] args) {
        
         Scanner sc = new Scanner(System.in);
         System.out.println("Introduce la hora en formato XX:XX");
         
    }
}
