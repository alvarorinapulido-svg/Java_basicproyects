/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioscondicionales;

import java.util.Scanner;

/**
 *
 * @author alvaro.rinpul
 */
public class Ejercicio18 {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce un numero de 5 cifras");
        int num1 = sc.nextInt();
        if (num1>99999){
            while (num1 >= 10) {
                num1 = num1 / 10; 
            }
            System.out.println("La primera cifra es: " + num1);
        }else{
            System.out.println("No se puede con mas de 5 cifras");
        }
    }
}
