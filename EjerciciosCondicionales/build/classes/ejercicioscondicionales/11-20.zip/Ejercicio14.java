/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioscondicionales;

import java.util.Scanner;

/**
 *
 * @author alvaro.rinpul
 */
public class Ejercicio14 {
    
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce un numero");
        int num1 = sc.nextInt();
        if (num1%2==0){
            System.out.println("Es par");
        }else{
            System.out.println("Es impar");
        }
        if (num1%5==0){
            System.out.println("El numero " + num1 + " es divisible por 5.");
        } else {
            System.out.println("El numero " + num1 + " no es divisible por 5.");
        }
    }
}
