/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioscondicionales;

import java.util.Scanner;

/**
 *
 * @author alvaro.rinpul
 */
public class Ejercicio13 {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce el primer número entero:");
        int num1 = sc.nextInt();
        System.out.println("Introduce el segundo número entero:");
        int num2 = sc.nextInt();
        System.out.println("Introduce el tercero número entero:");
        int num3 = sc.nextInt();
        
        if (num1 <= num2 && num1 <= num3) {
            System.out.print(num1 + ", ");
            if (num2 <= num3) {
                System.out.println(num2 + ", " + num3);
            } else {
                System.out.println(num3 + ", " + num2);
            }
        } else if (num2 <= num1 && num2 <= num3) {
            System.out.print(num2 + ", ");
            if (num1 <= num3) {
                System.out.println(num1 + ", " + num3);
            } else {
                System.out.println(num3 + ", " + num1);
            }
        } else {
            System.out.print(num3 + ", ");
            if (num1 <= num2) {
                System.out.println(num1 + ", " + num2);
            } else {
                System.out.println(num2 + ", " + num1);
            }
        }
    }
    
}
