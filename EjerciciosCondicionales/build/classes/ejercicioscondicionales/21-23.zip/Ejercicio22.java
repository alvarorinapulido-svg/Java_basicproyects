/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioscondicionales;

import java.util.Scanner;

/**
 *
 * @author alvaro.rinpul
 */
public class Ejercicio22 {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce el dia de la semana");
        String diaSemana = sc.nextLine();
        if (diaSemana == "Sabado" || diaSemana=="Domingo"){
            System.out.println("Ya es finde semana");
        }
        System.out.println("Introduce la hora");
        int hora = sc.nextInt();
        if (hora>15  & diaSemana=="Viernes"){
            System.out.println("Ya es finde semana");
        }
        System.out.println("Introduce los minutos");
        int minutos = sc.nextInt();
        final int minutosTotales = 6660;
        int numSemana = 0;
        switch (diaSemana){
            case "Lunes": numSemana=0;
            break;
            case "Martes": numSemana=1;
            break;
            case "Miercoles": numSemana=2;
            break;
            case "Jueves": numSemana=3;
            break;
            case "Viernes": numSemana=4;
            break;
        }
        int minutosRestantes;
        minutosRestantes=(minutosTotales)-((numSemana*24*60)+(hora*60)+minutos);
        System.out.println("Te quedan "+minutosRestantes+" minutos para el fin de semana");
    }
    
}
