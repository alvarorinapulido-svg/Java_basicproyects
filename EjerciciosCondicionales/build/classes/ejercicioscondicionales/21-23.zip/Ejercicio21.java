/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioscondicionales;

import java.util.Scanner;

/**
 *
 * @author alvaro.rinpul
 */
public class Ejercicio21 {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce la nota del primer examen");
        float nota1 = sc.nextFloat();
        System.out.println("Introduce la nota del segundo examen");
        float nota2 = sc.nextFloat();
        float media = (nota1+nota2)/2;
        if (media > 5){
            System.out.println("Tu media es de " + media);
        }else{
            System.out.println("Tienes que ir a recuperacion");
        }
        
    }
}
