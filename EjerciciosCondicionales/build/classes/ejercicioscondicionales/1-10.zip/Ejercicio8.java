/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioscondicionales;

import java.util.Scanner;

/**
 *
 * @author alvar
 */
public class Ejercicio8 {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Escribe la nota de los examenes");
        float nota1 = sc.nextFloat();
        System.out.println("Introduce otra nota");
        float nota2 = sc.nextFloat();
        System.out.println("Introduce la ultima nota");
        float nota3 = sc.nextFloat();
        float media;
        media = (nota1 + nota2 + nota3)/3;
        if (media>=0 & media<5){
            System.out.println("Insuficiente");
        }else if (media>=5 & media<6){
            System.out.println("Suficiente");
        }else if (media>=6 & media<7){
            System.out.println("Bien");
        }else if (media>=7 & media <9){
            System.out.println("Notable");
        }else if (media>=9 & media<=10){
            System.out.println("Sobresaliente");
        }else{
            System.out.println("Nota no valida");
        }
        
    }
    
}
