/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioscondicionales;

import java.util.Scanner;

/**
 *
 * @author alvar
 */
public class Ejercicio6 {
    
    public static void main(String[] args) {
        
        final double g = 9.81; // aceleración de la gravedad en m/s^2
        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce la altura (en metros): ");
        double h = sc.nextDouble();

        if (h < 0) {
            System.out.println("La altura no puede ser negativa.");
        } else {
            double tiempo = Math.sqrt((2 * h) / g);
            System.out.printf("El tiempo de caida es "+ tiempo +" segundos.");
        }

    }
}
