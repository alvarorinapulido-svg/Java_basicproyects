/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioscondicionales;

import java.util.Scanner;

/**
 *
 * @author alvar
 */
public class Ejercicio9 {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce el valor de A");
        double valor1 = sc.nextInt();
        System.out.println("Introduce el valor de B");
        double valor2 = sc.nextInt();
        System.out.println("Introduce el valor de C");
        double valor3 = sc.nextInt();
        double valorx1, valorx2;
        double delta = Math.pow(valor2, 2)-4*valor1*valor3;
        if (delta<0){
            System.out.println("La ecuacion no tiene solucion");
        }else{
            valorx1 = (-valor2 + Math.sqrt(delta))/2*valor1;
            valorx2 = (-valor2 - Math.sqrt(delta))/2*valor1;
            System.out.println("X1 = " + valorx1);
            System.out.println("X2 = " + valorx2);
            
        }
        
    }
}
