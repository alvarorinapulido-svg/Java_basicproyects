/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioscondicionales;

import java.util.Scanner;

/**
 *
 * @author alvar
 */
public class Ejercicio4 {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce el numero de horas trabajadas");
        int horas = sc.nextInt();
        int salario, extras;
        if (horas<=40 & horas>=1){
            salario = horas*12;
            System.out.println("Has ganado " + salario + " esta semana");
        }
        else if (horas>40 & horas<=168){
            extras=horas-40;
            salario=((horas-extras)*12)+(extras*16);
            System.out.println("Has ganado " + salario + " esta semana");
        }
        else{
            System.out.println("No es posible hacer la operacion");
        }
    }
    
}
