/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicioscondicionales;

import java.util.Scanner;

/**
 *
 * @author alvar
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce la hora en formato 24h");
        int hora = sc.nextInt();
        if (hora>=6 & hora<=12){
            System.out.println("Buenos dias");
        }
        else if (hora>=13 & hora<=20){
            System.out.println("Buenas tardes");
        }
        else if (hora>=21 & hora<=24){
            System.out.println("Buenas noches");
        }
        else if (hora>=0 & hora<=5){
            System.out.println("Buenas noches");
        }
        else{
            System.out.println("Hora no valida");
        }
    }
}
