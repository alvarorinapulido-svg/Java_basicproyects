/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioscondicionales;

import java.util.Scanner;

/**
 *
 * @author alvar
 */
public class Ejercicio5 {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce el valor a");
        int cifra1 = sc.nextInt();
        System.out.println("Introduce el valor b");
        int cifra2 = sc.nextInt();
        float cifrax = -cifra2/cifra1;
        System.out.println(cifrax);
        
    }
    
}
