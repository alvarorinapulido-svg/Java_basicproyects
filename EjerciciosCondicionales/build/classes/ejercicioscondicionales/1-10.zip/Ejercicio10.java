/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioscondicionales;

import java.util.Scanner;

/**
 *
 * @author alvar
 */
public class Ejercicio10 {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce el dia del mes");
        int dia = sc.nextInt();
        System.out.println("Introduce el mes (1-12)");
        int mes = sc.nextInt();
        String simbolo = "";
        if (mes==3 & dia>=21 || mes==4 & dia<=19){
            simbolo = "Aries";
        }else if (mes==4 & dia>=20 || mes==5 & dia<=20){
            simbolo = "Tauro";
        }else if (mes==5 & dia>=21 || mes==6 & dia<=20){
            simbolo = "Geminis";
        }else if (mes==6 & dia>=21 || mes==7 & dia<=22){
            simbolo = "Cancer";
        }else if (mes==7 & dia>=23 || mes==8 & dia<=22){
            simbolo = "Leo";
        }else if (mes==8 & dia>=23 || mes==9 & dia<=22){
            simbolo = "Virgo";
        }else if (mes==9 & dia>=23 || mes==10 & dia<=22){
            simbolo = "Libra";
        }else if (mes==10 & dia>=23 || mes==11 & dia<=21){
            simbolo = "Escorpio";
        }else if (mes==11 & dia>=22 || mes==12 & dia<=21){
            simbolo = "Sagitario";
        }else if (mes==12 & dia>=22 || mes==1 & dia<=19){
            simbolo = "Capricornio";
        }else if (mes==1 & dia>=20|| mes==2 & dia<=18){
            simbolo = "Acuario";
        }else if (mes==2 & dia>=29 || mes==3 & dia<=20){
            simbolo = "Piscis";
        }else{
            System.out.println("No es ");
        }
        System.out.println("Tu signo del zodiaco es: " + simbolo);
    }
}
