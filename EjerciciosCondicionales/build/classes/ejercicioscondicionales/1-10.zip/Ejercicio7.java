/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioscondicionales;

import java.util.Scanner;

/**
 *
 * @author alvar
 */
public class Ejercicio7 {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Escribe la nota de los examenes");
        float nota1 = sc.nextFloat();
        System.out.println("Introduce otra nota");
        float nota2 = sc.nextFloat();
        System.out.println("Introduce la ultima nota");
        float nota3 = sc.nextFloat();
        float media;
        media = (nota1 + nota2 + nota3)/3;
        System.out.println("Tu nota media es " + media);
        
    }
    
}
