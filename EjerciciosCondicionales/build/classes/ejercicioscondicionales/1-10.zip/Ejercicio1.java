/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package condicionales;

import java.util.Scanner;

/**
 *
 * @author alvaro.rinpul
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        String[] diaSemana={
            "Lunes",
            "Martes",
            "Miercoles",
            "Jueves",
            "Viernes",
        };
        String[] asignaturas={
            "Base de datos",
            "Ingles profesional",
            "Ingles profesional",
            "Entornos de Desarrollo",
            "Asignatura Optativa",
        };
        
        System.out.println("Introduce un dia");
        Scanner sc = new Scanner(System.in);
        int dias = sc.nextInt();
        dias = dias - 1;
        if (dias >= 1 && dias <=5){
            int asignado = dias - 1;
            System.out.println("El dia " + diaSemana[asignado] + " y te toca " + asignaturas[asignado]);
        }
        
    }
}   
        
    

